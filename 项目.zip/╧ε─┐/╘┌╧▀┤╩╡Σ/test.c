/*************************************************************************
  > File Name: test.c
  > Author: wsf
  > Mail: wusf@farsight.cn 
  > Created Time: Wed 17 Aug 2016 10:13:04 AM CST
 ************************************************************************/

#include<stdio.h>
#include <stdlib.h>
#include <string.h>

#define NONE                 "\e[0m"
#define BLACK                "\e[0;30m"
#define L_BLACK              "\e[1;30m"
#define RED                  "\e[0;31m"
#define L_RED                "\e[1;31m"
#define GREEN                "\e[0;32m"
#define L_GREEN              "\e[1;32m"
#define BROWN                "\e[0;33m"
#define YELLOW               "\e[1;33m"
#define BLUE                 "\e[0;34m"
#define L_BLUE               "\e[1;34m"
#define PURPLE               "\e[0;35m"
#define L_PURPLE             "\e[1;35m"
#define CYAN                 "\e[0;36m"
#define L_CYAN               "\e[1;36m"
#define GRAY                 "\e[0;37m"
#define WHITE                "\e[1;37m"

#define BOLD                 "\e[1m"
#define UNDERLINE            "\e[4m"
#define BLINK                "\e[5m"
#define REVERSE              "\e[7m"
#define HIDE                 "\e[8m"
#define CLEAR                "\e[2J"
#define CLRLINE              "\r\e[K" //or "\e[1K\r"

int main(int argc, const char *argv[])
{
	char buf[1024];
	FILE *fp = NULL;
	char word[20];
	int flag;

	if((fp = fopen("./dict.txt", "r")) == NULL)
	{
		perror("FOPEN ERROR");
		exit(-1);
	}

	while(1)
	{
		rewind(fp);
		bzero(word, sizeof(word));
		printf( RED "INPUT WORD:>" NONE);
		scanf("%s", word);

		bzero(buf, sizeof(buf));
		while(fgets(buf, sizeof(buf), fp) != NULL)
		{
			flag = 1;
			if(!strncmp(buf, word, strlen(word)) && buf[strlen(word)] == ' ')
			{
				flag = 0;
				printf(GREEN "%s:%s\n " NONE, word, buf+strlen(word));
				break;
			}
		}
		if(flag)
			printf("NOT FIND WORD.\n");
	}

	fclose(fp);
	return 0;
}



