#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sqlite3.h>
#include <signal.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <sys/types.h>



typedef struct sockaddr SA;

typedef struct 
{
	int type;
	char name[20];
	char data[256];   // password or word
} TEL;
int do_register(int fdb, TEL *buf, sqlite3 *db);
int do_login(int fdb, TEL *buf, sqlite3 *db);
int do_query(int fdb,TEL *buf, sqlite3 *db);
int do_history(int fdb,TEL *buf, sqlite3 *db);
void get_time(char date[]);
int history_callback(void *arg, int num, char **value, char **name);
int query_user(sqlite3 *db);
int change_info(sqlite3 *db);
int history_callback_a(void *arg, int num, char **value, char **name);
int do_server(sqlite3 *db);
int info_change_cli(int fdb,TEL *buf, sqlite3 *db);