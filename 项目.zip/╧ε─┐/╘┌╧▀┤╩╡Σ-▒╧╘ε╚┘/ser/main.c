#include "include.h"

int main(int argc, char const *argv[])
{
	int fda,fdb,maxfd,i;
	int n;
	socklen_t len;
	pid_t pid;
	struct sockaddr_in myaddr,cliaddr;
	sqlite3 *db;
	TEL buf;
	fd_set rdfs;





	if (sqlite3_open("info.db", &db) != SQLITE_OK)
	{
		printf("error : %s\n", sqlite3_errmsg(db));
		exit(-1);
	}

	if (argc < 3)
	{
		printf("Usage : %s <ip> <port>\n", argv[0]);
		exit(-1);
	}

	

	fda = socket(AF_INET,SOCK_STREAM,0);
	if(fda<0)
	{
		perror("socket error");
		exit(-1);
	}

	bzero(&myaddr, sizeof(myaddr));
	myaddr.sin_family = AF_INET;
	myaddr.sin_port = htons(atoi(argv[2]));
	myaddr.sin_addr.s_addr = inet_addr(argv[1]);

	if(bind(fda,(struct sockaddr *)&myaddr,sizeof(myaddr))<0)
	{
		perror("bind error");
		exit(-1);
	}

	if(listen(fda,5)<0)
	{
		perror("listen error");
		exit(-1);
	}
	maxfd = fda;

	printf("************************************\n");
	printf("* 1: query_user 2: change_info 3: quit *\n");
	printf("************************************\n");
	//printf("please choose : ");
	signal(SIGCHLD,SIG_IGN);
	while(1)
	{	
		FD_ZERO(&rdfs);
		FD_SET(0,&rdfs);
		FD_SET(fda,&rdfs);

		if(select(maxfd+1,&rdfs,NULL,NULL,NULL)<0)
		{
			perror("fail to select");
			exit(-1);
		}
		for(i = 0;i <= maxfd;i++ )
		{
			if(FD_ISSET(i,&rdfs))
			{
				if(i == 0)
				{
					do_server(db);
				}
				else if(i == fda)
				{
					len = sizeof(cliaddr);
					fdb = accept(fda,(struct sockaddr *)&cliaddr,&len);
					if(fdb<0)
					{
						perror("accept error");
						exit(-1);
					}
					/*
					pid = fork();
					if(pid < 0)
					{
						perror("fork error");
						exit(-1);
					}*/
					//else if(pid ==0)
				
					while(recv(fdb,&buf,sizeof(buf),0)>0)
						{	
							switch(buf.type)
							{
								case 1:
									do_register(fdb, &buf, db);
								break;
								case 2:
									do_login(fdb, &buf, db);
								break;
								case 3:
					  				do_query(fdb, &buf, db);
								break;
								case 4:
									do_history(fdb, &buf, db);
								break;
								case 5:
									info_change_cli(fdb, &buf, db);
								break;
							}	
						}
					close(fdb);

				

				}
			}
		}


	}

	return 0;
}