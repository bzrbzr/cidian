#include "include.h"

int do_register(int fdb, TEL *buf, sqlite3 *db)
{
	char a[128];
	char *errmsg;


	sprintf(a, "insert into user values ('%s', '%s');", buf->name, buf->data);
	printf("%s    %s\n", buf->name, buf->data);
	if(sqlite3_exec(db,a,NULL,NULL,&errmsg) != SQLITE_OK)
	{
		sqlite3_free(errmsg);
		sprintf(buf->data, "user %s already exist!!!", buf->name);
	}
	else
	{
		strncpy(buf->data, "OK", 256);
	}
	send(fdb,buf,sizeof(TEL),0);
}
int do_login(int fdb, TEL *buf, sqlite3 *db)
{
	char a[128];
	char *errmsg,**result;
	int nrow, ncolumn;

	sprintf(a,"select * from user where name='%s'and data='%s';",buf->name,buf->data);
	if (sqlite3_get_table(db, a, &result, &nrow, &ncolumn, &errmsg) != SQLITE_OK)
	{
		printf("error : %s\n", errmsg);
		sqlite3_free(errmsg);
	}

	if (nrow == 0)
	{
		strncpy(buf->data, "name or password is wrong!!!", 256);
	}
	else
	{
		strncpy(buf->data, "OK", 256);
	}
	send(fdb, buf, sizeof(TEL), 0);
	sqlite3_free_table(result);
}

int do_query(int fdb,TEL *buf, sqlite3 *db)
{
	FILE *fp = NULL;
	char b[512];
	char sqlstr[128];
	int result,len;
	int flag = 1;
	char *p,*errmsg;
	//char time[64];
	char word[64];
	//printf("%s\n",time);
	bzero(word, sizeof(word));
	strcpy(word, buf->data);

	if((fp = fopen("dict.txt", "r")) == NULL)
	{
		strcpy(buf->data, "dict on server can't be opened :(");
		send(fdb, buf, sizeof(TEL), 0);
	}
	len = strlen(buf->data);
	while(fgets(b,512,fp) != NULL)
	{
		result = strncmp(buf->data, b, len);
		if(result>0)
			continue;
		else if(result<0||b[len] !=' ')
			break;
		else if(result == 0)
		{
			flag = 0;
		}
		p = b + len;
		while (*p == ' ') p++;
		strcpy(buf->data, p);
		send(fdb, buf, sizeof(TEL), 0);
		fclose(fp);
	}
	if(flag)
	{
		strcpy(buf->data,"the word can not found");
		send(fdb, buf, sizeof(TEL), 0);
	}
	
	else
	{
		//bzero(time, sizeof(time));
		//get_time(time);
		sprintf(sqlstr, "insert into record (name,word) values('%s','%s');", buf->name, word);
		if (sqlite3_exec(db, sqlstr, NULL, NULL, &errmsg) != SQLITE_OK)
		{
			printf("error : %s\n", errmsg);
			sqlite3_free(errmsg);
		}
	}
	return 0;
}
/*
void get_time(char date[])
{
	time_t t;
	struct tm *tp;

	time(&t);
	
	tp = localtime(&t);
	strftime(date, 64, "%Y-%m-%d %H:%M:%S", tp);

	return;
}*/
int do_history(int fdb,TEL *buf, sqlite3 *db)
{
	char sqlstr[128], *errmsg;
	//printf("------------------119----------\n");

	sprintf(sqlstr, "select * from record where name = '%s'", buf->name);
	if (sqlite3_exec(db, sqlstr, history_callback, (void *)&fdb, &errmsg) != SQLITE_OK)
	{
		printf("error : %s\n", errmsg);
		sqlite3_free(errmsg);
	}
	buf->data[0] = '\0';
	send(fdb, buf, sizeof(TEL), 0);
	
	return;
}

int history_callback(void *arg, int num, char **value, char **name)
{
	int fdb;
	TEL buf;
	fdb = *(int *)arg;
	//printf("------------------138----------\n");
	sprintf(buf.data, "%s : %s", value[1], value[2]);
	send(fdb, &buf, sizeof(TEL), 0);
	return 0;
}

int query_user(sqlite3 *db)
{
	char sqlstr[128], *errmsg;
	char info[100];

	sprintf(sqlstr, "select * from user");
	if (sqlite3_exec(db, sqlstr, history_callback_a, 0, &errmsg) != SQLITE_OK)
	{
		printf("error : %s\n", errmsg);
		sqlite3_free(errmsg);
	}
	info[100] = '\0';
	printf("%s\n",info);
	printf("----------------157--------------\n");
  	do_server(db);

}

int change_info(sqlite3 *db)
{
	char sqlstr[128], *errmsg;
	char *argv[20];
	char buf1[20],buf2[20],buf3[20];
	printf("please input the name that you want to change\n");
	scanf("%s",buf3);
	printf("please input the new name\n");
	scanf("%s",buf1);
	printf("please input the new data\n");
	scanf("%s",buf2);
	sprintf(sqlstr, "update user set name='%s',data='%s'where name='%s';",buf1,buf2,buf3);
	if (sqlite3_exec(db, sqlstr, 0, 0, &errmsg) != SQLITE_OK)
	{
		printf("error : %s\n", errmsg);
		sqlite3_free(errmsg);
	}
	do_server(db);
}

int history_callback_a(void *arg, int num, char **value, char **name)
{
	char info[100];
	sprintf(info, "%s : %s", value[0], value[1]);
	printf("%s\n",info);
	return 0;
}

int do_server(sqlite3 *db)
{
	int n;
	printf("************************************\n");
	printf("* 1: query_user 2: change_info 3: quit *\n");
	printf("************************************\n");
	//printf("please choose : ");
	scanf("%d",&n);
	switch(n)
	{
		case 1:
			query_user(db);
			break;
		case 2:
			change_info(db);
			break;
		case 3:
			exit(0);
	}
}

int info_change_cli(int fdb,TEL *buf, sqlite3 *db)
{
	char sqlstr[128], *errmsg;
	printf("%s\n", buf->name);
	printf("%s\n", buf->data);
	sprintf(sqlstr, "update user set name='%s',data='%s'where name='%s';l",buf->name,buf->data,buf->name);
	if (sqlite3_exec(db, sqlstr, 0, 0, &errmsg) != SQLITE_OK)
	{
		printf("error : %s\n", errmsg);
		sqlite3_free(errmsg);
	}

}