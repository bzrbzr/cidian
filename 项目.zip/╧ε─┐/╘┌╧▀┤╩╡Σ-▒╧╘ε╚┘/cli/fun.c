#include "include.h"

int sqlite(int fda,TEL *buf)
{
	int n;
	while(1)
	{
		printf("***********************************************\n");
		printf("* 1: query_word        2: history_record   *\n");
		printf("* 3: change_info       4: quit              *\n");
		printf("***********************************************\n");
		printf("please choose : ");
		scanf("%d",&n);
		switch(n)
		{
			case 1:
				query_word(fda,buf);
				break;
			case 2:
				history_record(fda,buf);
				break;
			case 3:
				change_info(fda,buf);
				break;
			case 4:
				close(fda);
				exit(0);
		}
	}
	return 0;
}

int query_word(int fda,TEL *buf)
{
	buf->type = 3;
	//while(1)
	{
		printf("-------------querying-------------\n");
		printf("please input word:\n");
		scanf("%s",buf->data);
		//if (strcmp(buf->data, "#") == 0) break;
		send(fda,buf,sizeof(TEL),0);//sizeof(buf)ceshi
		recv(fda,buf,sizeof(TEL),0);
		printf("%s\n",buf->data);
		printf("\n");
		//sqlite(fda, buf);
	}
	
}

int history_record(int fda,TEL *buf)
{
	buf->type = 4;
	printf("--------history_record---------\n");
	send(fda,buf,sizeof(TEL),0);
	while(1)
	{
		recv(fda,buf,sizeof(TEL),0);
		if(buf->data[0] == '\0') break;
		printf("%s\n",buf->data);
	}

}

int do_register(int fda,TEL *buf)
{
	printf("-------------registing-------------\n");
	buf->type = 1;
	printf("please input name:\n");
	scanf("%s",buf->name);
	printf("please input password:\n");
	scanf("%s",buf->data);
	send(fda,buf,sizeof(TEL),0);//sizeof(buf)ceshi
	recv(fda,buf,sizeof(TEL),0);
	printf("%s\n",buf->data);
	return 0;

}

int do_login(int fda,TEL *buf)
{
	printf("-------------logining-------------\n");
	buf->type = 2;
	printf("please input name:\n");
	scanf("%s",buf->name);
	printf("please input password:\n");
	scanf("%s",buf->data);
	send(fda,buf,sizeof(TEL),0);//sizeof(buf)ceshi
	recv(fda,buf,sizeof(TEL),0);
	if (strncmp(buf->data, "OK", 3) == 0) 
	{
		printf("login : OK\n");
		return 1;
	}
	printf("login : %s\n", buf->data);

	return 0;
}

int change_info(int fda,TEL *buf)
{
	char a[20],b[20];
	printf("-------------changing-------------\n");
	buf->type = 5;
	printf("please input name:\n");
	scanf("%s",buf->name);
	printf("please input password:\n");
	scanf("%s",a);
	printf("please input password again:\n");
	scanf("%s",b);
	if(strcmp(a,b)!=0)
	{
		printf("The two passwords differ\n");
		change_info(fda,buf);
	}
	else
	{
		if(panduan(a) == 1)
		{
			strcpy(buf->data,a);
			send(fda,buf,sizeof(TEL),0);																																						
		}
		else
		{
			printf("password format is error\n");
			change_info(fda,buf);
		}
	}
}

int panduan(char str[100])
{
    int flag1 = 1;
    int flag2 = 1;
    int flag3 = 1;
    int flag4 = 1;
    int i = 0;
    for(  i = 0; i < strlen(str); i++ )
    {
        if( str[i] >= '0' && str[i] <='9' )
            continue;
        else
        {
            flag1 = 0;
            break;
        }
    }
    for(  i = 0; i < strlen(str); i++ )
    {
        if( str[i] >= 'a' && str[i] <='z' )
            continue;
        else
        {
            flag2 = 0;
            break;
        }
    }
    for( i = 0; i < strlen(str); i++ )
    {
        if( str[i] >= 'A' && str[i] <='Z' )
            continue;
        else
        {
            flag3 = 0;
            break;
        }
    }
    if(strlen(str)>=6)
    {
    		flag4 = 0;
    }
    if( flag1 == 0&&flag2 == 0&&flag3 == 0&&flag4 == 0)
    		return 1;
    else
    		return 0;
}