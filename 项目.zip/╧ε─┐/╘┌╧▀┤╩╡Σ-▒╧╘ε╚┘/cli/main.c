#include "include.h"

int main(int argc, char const *argv[])
{
	int fda;
	int n;
	TEL buf;
	struct sockaddr_in servaddr;

	if (argc < 3)
	{
		printf("Usage : %s <serv_ip> <serv_port>\n", argv[0]);
		exit(-1);
	}

	fda = socket(AF_INET,SOCK_STREAM,0);
	if(fda<0)
	{
		perror("socket error");
		exit(-1);
	}

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(atoi(argv[2]));
	servaddr.sin_addr.s_addr = inet_addr(argv[1]);

	if(connect(fda,(struct sockaddr *)&servaddr,sizeof(servaddr))<0)
	{
		perror("connect error");
		exit(-1);
	}

	while(1)
	{
		printf("************************************\n");
		printf("* 1: register   2: login   3: quit *\n");
		printf("************************************\n");
		printf("please choose : ");
		scanf("%d",&n);
		switch(n)
		{
			case 1:
				do_register(fda, &buf);
				break;
			case 2:
				if(do_login(fda, &buf) == 1)
				{
					sqlite(fda, &buf);
				}
				break;
			case 3:
				close(fda);
				exit(0);
		}

	}
	return 0;
}
