#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sqlite3.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

typedef struct 
{
	int type;
	char name[20];
	char data[256];
}TEL;

int sqlite(int fda,TEL *buf);
int query_word(int fda,TEL *buf);
int history_record(int fda,TEL *buf);
int do_register(int fda,TEL *buf);
int do_login(int fda,TEL *buf);
int change_info(int fda,TEL *buf);
int panduan(char str[20]);